%ACL Clear ALL variables from workspace and console
clear all;
clc;